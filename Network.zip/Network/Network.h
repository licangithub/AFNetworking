//
//  Network.h
//  HoolayLibrary
//
//  Created by WangMike on 15/4/22.
//  Copyright (c) 2015年 WangMike. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NetworkInterface.h"

typedef void(^NetworkHandle)(NSDictionary*,NSError*);

@interface Network : NSObject<NetworkInterface>
-(instancetype) initWithBaseURL:(NSString*)baseURL headers:(NSDictionary*) headers;
@end

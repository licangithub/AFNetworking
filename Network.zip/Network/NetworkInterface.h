//
//  Network.h
//  HoolayLibrary
//
//  Created by WangMike on 15/4/22.
//  Copyright (c) 2015年 WangMike. All rights reserved.
//

#import <Foundation/Foundation.h>

#define NetworkModuleName @"Network"

extern NSString * HoolayNetworkErrorDomain;

typedef void(^NetworkHandle)(NSDictionary*,NSError*);

typedef NS_ENUM(NSUInteger, NetworkTaskState) {
    NetworkTaskStateRunning = 0,
    NetworkTaskStateSuspended = 1,
    NetworkTaskStateCanceling = 2,
    NetworkTaskStateCompleted = 3,
};

@protocol NetworkTask <NSObject>
@property (nonatomic,readonly) int64_t totalBytes;
@property (nonatomic,readonly) int64_t completedBytes;
@property (nonatomic,readonly) NetworkTaskState state;
-(void) cancel;
@end

@protocol NetworkDelegate <NSObject>
-(void) network:(id) network method:(NSString*)method necessaryParameters:(void(^)(NSDictionary*,NSError*)) block;
-(void) network:(id) network method:(NSString*)method onError:(NSError*) error;
@end

@protocol NetworkInterface <NSObject>
@property (nonatomic,weak) id<NetworkDelegate> delegate;

-(id<NetworkTask>) GET:(NSString*) method parameters:(NSDictionary*) parameters handle:(NetworkHandle) handel;
-(id<NetworkTask>) POST:(NSString*) method parameters:(NSDictionary*) parameters handle:(NetworkHandle) handel;
-(id<NetworkTask>) PUT:(NSString*) method parameters:(NSDictionary*) parameters handle:(NetworkHandle) handel;
-(id<NetworkTask>) DELETE:(NSString*) method parameters:(NSDictionary*) parameters handle:(NetworkHandle) handel;
@end

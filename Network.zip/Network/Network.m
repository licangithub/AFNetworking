//
//  Network.m
//  HoolayLibrary
//
//  Created by WangMike on 15/4/22.
//  Copyright (c) 2015年 WangMike. All rights reserved.
//

#import "Network.h"
#import <AFHTTPRequestOperationManager.h>
#import <Objection/Objection.h>

typedef void(^AFNetworkHandel)(AFHTTPRequestOperation*,id);

NSString * HoolayNetworkErrorDomain = @"__HoolayNetworkErrorDomain";


@interface NetworkAsyncTask : NSObject<NetworkTask>
@property (nonatomic,strong) AFHTTPRequestOperation * task;
@property (nonatomic,readonly) int64_t totalBytes;
@property (nonatomic,readonly) int64_t completedBytes;
@property (nonatomic,readwrite,assign) NetworkTaskState state;
@end

@implementation NetworkAsyncTask
-(void) cancel{
    if (!_task){
        _state = NetworkTaskStateCompleted;
    }
    [_task cancel];
}
-(NetworkTaskState) state{
    return NetworkTaskStateRunning;
//    return  (NetworkTaskState)(_task ? _task.state : _state);
}
-(int64_t) totalBytes{
//    NSString * method = [[_task.currentRequest HTTPMethod] uppercaseString];
//    if ([method isEqualToString:@"POST"] || [method isEqualToString:@"PUT"]) {
//        return _task.countOfBytesSent + _task.countOfBytesExpectedToSend;
//    }else{
//        return _task.countOfBytesReceived + _task.countOfBytesExpectedToReceive;
//    }
    return 0;
}
-(int64_t) completedBytes{
//    NSString * method = [[_task.currentRequest HTTPMethod] uppercaseString];
//    if ([method isEqualToString:@"POST"] || [method isEqualToString:@"PUT"]) {
//        return _task.countOfBytesSent;
//    }else{
//        return _task.countOfBytesReceived;
//    }
    return 0;
}
@end


@interface Network ()
@property (nonatomic,strong) AFHTTPRequestOperationManager * afMgr;
@property (nonatomic,strong) AFNetworkReachabilityManager * raMgr;

@property (nonatomic,strong,readwrite) NSString * baseURL;
@property (nonatomic,strong) NSDictionary * headers;
@end

@implementation Network
@synthesize delegate;
objection_initializer(initWithBaseURL:headers:)

-(id) init{
    self = [super init];
    if (self) {
        [self setupManage];
    }
    return self;
}
-(instancetype) initWithBaseURL:(NSString*)baseURL headers:(NSDictionary*) headers{
    self = [super init];
    if (self){
        self.baseURL = baseURL;
        self.headers = headers;
        [self setupManage];
    }
    return self;
}
-(void) setupManage{
    _raMgr = [AFNetworkReachabilityManager managerForDomain:[self.baseURL stringByDeletingLastPathComponent]];
    [_raMgr startMonitoring];
    
    _afMgr = [[AFHTTPRequestOperationManager alloc] initWithBaseURL:[NSURL URLWithString:self.baseURL]];
    _afMgr.requestSerializer = [AFHTTPRequestSerializer serializer];
    _afMgr.responseSerializer = [AFJSONResponseSerializer serializer];
}

-(void) method:(NSString*) method response:(id) data error:(NSError*)error task:(AFHTTPRequestOperation*) task handle:(NetworkHandle) handle{
    if (data) {
        !handle ?: handle(data,nil);
    }else{
//        if (!_raMgr.isReachable) {
//            error = [NSError errorWithDomain:HoolayNetworkErrorDomain code:-1 userInfo:@{@"message":@"网络暂不可用."}];
//        }else
        {
            NSHTTPURLResponse* response = (NSHTTPURLResponse*)task.response;
            NSInteger state = response.statusCode;
            if (state == 400){
                error = [NSError errorWithDomain:HoolayNetworkErrorDomain code:-1 userInfo:[NSJSONSerialization JSONObjectWithData:task.responseData options:0 error:nil]];
            }
        }
        if ([delegate respondsToSelector:@selector(network:method:onError:)]) {
            [delegate network:self method:method onError:error];
        }
        !handle ?: handle(nil,error);
    }
}

-(id<NetworkTask>) preprocess:(NSString*) method parameters:(NSDictionary*)parameters handle:(NetworkHandle) handel block:(AFHTTPRequestOperation*(^)(NSString* method,NSDictionary* parameters,AFNetworkHandel success, AFNetworkHandel failure)) block{
    NetworkAsyncTask * task = [NetworkAsyncTask new];
    if ([delegate respondsToSelector:@selector(network:method:necessaryParameters:)]){
        [delegate network:self method:method necessaryParameters:^(NSDictionary * necessaryParameters,NSError* error) {
            if (task.state == NetworkTaskStateRunning){
                if (error){
                    [self method:method response:nil error:error task:nil handle:handel];
                }else{
                    NSMutableDictionary * dict = [NSMutableDictionary dictionaryWithDictionary:parameters];
                    [dict addEntriesFromDictionary:necessaryParameters];
                    task.task = block(method,dict,^(AFHTTPRequestOperation *task, id responseObject) {
                        [self method:method response:responseObject error:nil task:task handle:handel];
                    },^(AFHTTPRequestOperation *task, NSError *error) {
                        [self method:method response:nil error:error task:task handle:handel];
                    });
                }
            }
        }];
    }else{
        task.task = block(method,parameters,^(AFHTTPRequestOperation *task, id responseObject) {
            [self method:method response:responseObject error:nil task:task handle:handel];
        },^(AFHTTPRequestOperation *task, NSError *error) {
            [self method:method response:nil error:error task:task handle:handel];
        });
    }
    return nil;
}

-(id<NetworkTask>) GET:(NSString*) method parameters:(NSDictionary*) parameters handle:(NetworkHandle) handel{
    return [self preprocess:method parameters:parameters handle:handel block:^AFHTTPRequestOperation *(NSString *method, NSDictionary *parameters, AFNetworkHandel success, AFNetworkHandel failure) {
        return [_afMgr GET:method parameters:parameters success:success failure:failure];
    }];
}
-(id<NetworkTask>) POST:(NSString*) method parameters:(NSDictionary*) parameters handle:(NetworkHandle) handel{
    return [self preprocess:method parameters:parameters handle:handel block:^AFHTTPRequestOperation *(NSString *method, NSDictionary *parameters, AFNetworkHandel success, AFNetworkHandel failure) {
        return [_afMgr POST:method parameters:parameters success:success failure:failure];
    }];
}
-(id<NetworkTask>) PUT:(NSString*) method parameters:(NSDictionary*) parameters handle:(NetworkHandle) handel{
    return [self preprocess:method parameters:parameters handle:handel block:^AFHTTPRequestOperation *(NSString *method, NSDictionary *parameters, AFNetworkHandel success, AFNetworkHandel failure) {
        return [_afMgr PUT:method parameters:parameters success:success failure:failure];
    }];
}
-(id<NetworkTask>) DELETE:(NSString*) method parameters:(NSDictionary*) parameters handle:(NetworkHandle) handel{
    return [self preprocess:method parameters:parameters handle:handel block:^AFHTTPRequestOperation *(NSString *method, NSDictionary *parameters, AFNetworkHandel success, AFNetworkHandel failure) {
        return [_afMgr DELETE:method parameters:parameters success:success failure:failure];
    }];
}
@end


